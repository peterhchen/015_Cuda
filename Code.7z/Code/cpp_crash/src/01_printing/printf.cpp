// Prints "Hello, World!" to the console using printf
// By: Nick from CoffeeBeforeArch

#include <cstdio>

int main() {
  printf("Hello, World!\n");

  return 0;
}
