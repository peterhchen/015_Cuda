// Prints "Hello, World!" to the console using cout
// By: Nick from CoffeeBeforeArch

#include <iostream>

int main() {
  std::cout << "Hello, World!\n";

  return 0;
}
