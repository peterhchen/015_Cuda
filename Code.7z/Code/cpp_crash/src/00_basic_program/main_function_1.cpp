// The most simple program in C++
// By: Nick from CoffeeBeforeArch

int main(int argc, char *argv[]) { return 0; }
