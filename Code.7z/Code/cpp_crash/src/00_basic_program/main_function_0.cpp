// The most simple program in C++
// By: Nick from CoffeeBeforeArch

int main() { return 0; }
