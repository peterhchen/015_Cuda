// This program shows how to use if statements in C++
// By: Nick from CoffeeBeforeArch

#include <iostream>

int main() {
  // Declare and initialize variable
  int a = 5;

  // Only executes if a is equal to 5
  if (a == 5) {
    std::cout << "Inside if statement!\n";
  }

  return 0;
}
